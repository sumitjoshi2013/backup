﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AutoMapper;
using SETK.ViewModel;
using System.Configuration;
using SETK.Logger;
using System.Threading.Tasks;
using System.Data.Entity;
using SETK.DataModel;
using SETK.ViewModel.ViewModels.Ropes;

namespace SETK.Controllers
{/// <summary>
/// 
/// </summary>
    public class RopeController : ApiController
    {
        private readonly SETKEntities _dbContext;
        /// <summary>
        /// 
        /// </summary>
        public RopeController()
        {
            _dbContext = new SETKEntities();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("customers/headers")]
        public HttpResponseMessage GetViaHeaders(int pageNo = 1, int pageSize = 50)
        {
            AppTrace.Start("ValuesController", "sumit.joshij@gmail.com");
            List<RopeVM> destination = null;
            int skip = 0;
            int total = 0;
            int pageCount = 0;
            MapperConfiguration config = null;
            // Determine the number of records to skip
            RecordCount(pageNo, pageSize, out skip, out total, out pageCount);

            AppTrace.Information("Total Result" + total);
            try
            {


                var source = _dbContext.Ropes;
                config = MapperConfigs();

                destination = Mapper(pageSize, skip, source, config);

                AppTrace.Stop("ValuesController");
            }
            catch (Exception e)
            {
                AppTrace.Error(e.Message);

            }

            // Create the response
            var response = Request.CreateResponse(HttpStatusCode.OK, destination);

            // Set headers for paging
            ResponseHeader(pageNo, pageSize, total, pageCount, response);

            // Return the response
            return response;
        }

        private MapperConfiguration MapperConfigs()
        {
            return new MapperConfiguration(cfg =>
            {

                cfg.CreateMap<Rope, RopeVM>();

            });
        }

        private List<RopeVM> Mapper(int pageSize, int skip, DbSet<Rope> source, MapperConfiguration config)
        {
            List<RopeVM> destination;
            IMapper iMapper = config.CreateMapper();
            destination = iMapper.Map<List<Rope>, List<RopeVM>>(source
           .OrderBy(c => c.ID)
           .Skip(skip)
           .Take(pageSize)
           .ToList()
           );
            return destination;
        }

        private void ResponseHeader(int pageNo, int pageSize, int total, int pageCount, HttpResponseMessage response)
        {
            response.Headers.Add("X-Paging-PageNo", pageNo.ToString());
            response.Headers.Add("X-Paging-PageSize", pageSize.ToString());
            response.Headers.Add("X-Paging-PageCount", pageCount.ToString());
            response.Headers.Add("X-Paging-TotalRecordCount", total.ToString());
        }

        private void RecordCount(int pageNo, int pageSize, out int skip, out int total, out int pageCount)
        {
            skip = (pageNo - 1) * pageSize;

            // Get total number of records
            total = _dbContext.Ropes.Count();
            // Determine page count
            pageCount = total > 0
                ? (int)Math.Ceiling(total / (double)pageSize)
                : 0;
        }
    }
}
